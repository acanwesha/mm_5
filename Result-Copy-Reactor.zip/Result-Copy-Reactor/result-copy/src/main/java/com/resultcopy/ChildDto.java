package com.resultcopy;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Getter
@Setter
public class ChildDto implements Serializable {
    private int childId;
    private String fin;
    private String firstName;
    private String lastName;
    private String mrn;
    private Date resultCopiedDate;

}
