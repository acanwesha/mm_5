package com.resultcopy.service.dao;


import com.resultcopy.service.model.Child;
import com.resultcopy.service.model.Patient;
import com.resultcopy.service.model.PatientDetails;

import java.util.List;

public interface ChildDAO {

    List<PatientDetails> getPatientById(Integer patientId);

}
