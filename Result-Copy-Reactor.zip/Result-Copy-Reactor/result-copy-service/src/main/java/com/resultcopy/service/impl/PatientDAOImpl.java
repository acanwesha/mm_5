package com.resultcopy.service.impl;

import com.resultcopy.service.model.Patient;
import com.resultcopy.service.model.PatientDetails;
import com.resultcopy.service.ConnectionFactory;
import com.resultcopy.service.dao.PatientDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PatientDAOImpl implements PatientDAO {

    @Override
    public Patient getPatientById(Integer patientId) {

        Patient patient = null;
        PatientDetails pd = null;

        Connection con = ConnectionFactory.getConnection();
        String sql = " SELECT * FROM patient WHERE PATIENT_ID =  "+patientId;
        System.out.println("SQL :"+sql);
        try{
            PreparedStatement pStmt = con.prepareStatement(sql);
            ResultSet rs = pStmt.executeQuery();

            while (rs.next()) {
                pd= new PatientDetails();
                pd.setId(rs.getInt("PATIENT_ID"));
                pd.setFirstName(rs.getString("FIRST_NAME"));
                pd.setLastName(rs.getString("LAST_NAME"));
                pd.setMrn(rs.getString("MRN"));
                pd.setFin(rs.getString("FIN"));
            }
            patient = new Patient();
            patient.setPatientDetails(pd);
        }catch (SQLException ex){
            ex.printStackTrace();
        }

        return patient;
    }

    public static  void main(String args){
        PatientDAOImpl impl = new PatientDAOImpl();
        impl.getPatientById(1);
    }
}
