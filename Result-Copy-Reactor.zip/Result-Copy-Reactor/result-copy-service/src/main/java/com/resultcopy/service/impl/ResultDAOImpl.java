package com.resultcopy.service.impl;

import com.resultcopy.service.ConnectionFactory;
import com.resultcopy.service.dao.PatientDAO;
import com.resultcopy.service.dao.ResultDAO;
import com.resultcopy.service.model.Category;
import com.resultcopy.service.model.Result;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ResultDAOImpl implements ResultDAO {
    public List<Result> getCategories(Integer categoryId){
        PatientDAO patientDao=new PatientDAOImpl();
        Result result=null;
        Category category=null;
        List<Result> resultList=new ArrayList<>();
        Connection con = ConnectionFactory.getConnection();
        String sql = "SELECT rs.result_id,rs.result_name from result rs,category c where rs.category_id=c.category_id and c.category_id="+categoryId;
        System.out.println("SQL :"+sql);
        try{
            PreparedStatement pStmt = con.prepareStatement(sql);
            ResultSet rs = pStmt.executeQuery();

            while (rs.next()) {
                result=new Result();
                result.setId(rs.getInt("RESULT_ID"));
                result.setDisplayName(rs.getString("RESULT_NAME"));
                resultList.add(result);

            }
            category = new Category();
            category.setResult(resultList);
        }catch (SQLException ex){
            ex.printStackTrace();
        }

        category.setResult(resultList);
        return resultList;
    }
}
