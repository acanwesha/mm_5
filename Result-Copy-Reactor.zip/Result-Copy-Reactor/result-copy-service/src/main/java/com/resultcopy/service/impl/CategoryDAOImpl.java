package com.resultcopy.service.impl;

import com.resultcopy.service.ConnectionFactory;
import com.resultcopy.service.dao.CategoryDAO;
import com.resultcopy.service.model.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CategoryDAOImpl implements CategoryDAO {
    public List<Category> getCategories(){

        PatientResult patientResult= null;
        List<Category> categoryList= new ArrayList<>();
        Category cd=null;
        Connection con = ConnectionFactory.getConnection();
        String sql = "SELECT * from Category ";
        System.out.println("SQL :"+sql);
        try{
            PreparedStatement pStmt = con.prepareStatement(sql);
            ResultSet rs = pStmt.executeQuery();

            while (rs.next()) {
                cd=new Category();
                cd.setId(rs.getInt("CATEGORY_ID"));
                cd.displayName(rs.getString("CATEGORY_NAME"));
                categoryList.add(cd);
            }
            patientResult = new PatientResult();
            patientResult.setCategory(categoryList);
        }catch (SQLException ex){
            ex.printStackTrace();
        }

        patientResult.setCategory(categoryList);
        return categoryList;
    }

}
