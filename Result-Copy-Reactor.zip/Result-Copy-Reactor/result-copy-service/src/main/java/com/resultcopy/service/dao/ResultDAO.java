package com.resultcopy.service.dao;

import com.resultcopy.service.model.Result;

import java.util.List;

public interface ResultDAO {
    public List<Result> getCategories(Integer categoryId);
}
