package com.resultcopy.service.impl;

import com.resultcopy.service.ConnectionFactory;
import com.resultcopy.service.dao.BabyResultDAO;
import com.resultcopy.service.dao.PatientDAO;
import com.resultcopy.service.model.BabyResult;
import com.resultcopy.service.model.Patient;
import com.resultcopy.service.model.PatientDetails;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BabyResultDAOImpl implements BabyResultDAO {


    @Override
    public BabyResult getBabyPatientByChildId(Integer childId) {

        Connection con = ConnectionFactory.getConnection();
        String sql = " SELECT * FROM Baby_Result WHERE CHILD_ID =  "+childId;
        System.out.println("SQL :"+sql);
        BabyResult br = null;
        try{
            PreparedStatement pStmt = con.prepareStatement(sql);
            ResultSet rs = pStmt.executeQuery();

            while (rs.next()) {
                br = new BabyResult();

                br.setDateTime(rs.getDate("DATE_TIME"));

            }

        }catch (SQLException ex){
            ex.printStackTrace();
        }
        return br;
    }
}
